import { Component } from '@angular/core';

@Component({
  selector: 'app-dark-light-theme',
  standalone: true,
  imports: [],
  templateUrl: './dark-light-theme.component.html',
  styleUrl: './dark-light-theme.component.scss'
})
export class DarkLightThemeComponent {

}
