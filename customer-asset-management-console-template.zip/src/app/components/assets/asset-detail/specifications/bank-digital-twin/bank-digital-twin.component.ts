import { Component } from '@angular/core';

@Component({
  selector: 'app-bank-digital-twin',
  standalone: true,
  imports: [],
  templateUrl: './bank-digital-twin.component.html',
  styleUrl: './bank-digital-twin.component.scss'
})
export class BankDigitalTwinComponent {

}
