import { Component } from '@angular/core';

@Component({
  selector: 'app-book-service',
  standalone: true,
  imports: [],
  templateUrl: './book-service.component.html',
  styleUrl: './book-service.component.scss'
})
export class BookServiceComponent {

}
