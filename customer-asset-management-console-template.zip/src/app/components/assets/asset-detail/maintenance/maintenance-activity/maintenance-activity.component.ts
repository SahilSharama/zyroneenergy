import { Component } from '@angular/core';

@Component({
  selector: 'app-maintenance-activity',
  standalone: true,
  imports: [],
  templateUrl: './maintenance-activity.component.html',
  styleUrl: './maintenance-activity.component.scss'
})
export class MaintenanceActivityComponent {

}
