import { Component } from '@angular/core';

@Component({
  selector: 'app-app-bar',
  standalone: true,
  imports: [],
  templateUrl: './app-bar.component.html',
  styleUrl: './app-bar.component.scss'
})
export class AppBarComponent {

}
