import { Component } from '@angular/core';

@Component({
  selector: 'app-half-doughnut-chart',
  standalone: true,
  imports: [],
  templateUrl: './half-doughnut-chart.component.html',
  styleUrl: './half-doughnut-chart.component.scss'
})
export class HalfDoughnutChartComponent {

}
