import { Component } from '@angular/core';

@Component({
  selector: 'app-signin-signup',
  standalone: true,
  imports: [],
  templateUrl: './signin-signup.component.html',
  styleUrl: './signin-signup.component.scss'
})
export class SigninSignupComponent {

}
