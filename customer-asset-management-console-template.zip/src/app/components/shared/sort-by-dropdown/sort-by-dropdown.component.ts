import { Component } from '@angular/core';

@Component({
  selector: 'app-sort-by-dropdown',
  standalone: true,
  imports: [],
  templateUrl: './sort-by-dropdown.component.html',
  styleUrl: './sort-by-dropdown.component.scss'
})
export class SortByDropdownComponent {

}
