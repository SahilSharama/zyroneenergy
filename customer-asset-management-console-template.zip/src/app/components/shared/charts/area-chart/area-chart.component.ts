import { Component } from '@angular/core';

@Component({
  selector: 'app-area-chart',
  standalone: true,
  imports: [],
  templateUrl: './area-chart.component.html',
  styleUrl: './area-chart.component.scss'
})
export class AreaChartComponent {

}
