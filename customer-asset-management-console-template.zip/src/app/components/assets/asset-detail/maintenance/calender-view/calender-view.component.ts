import { Component } from '@angular/core';

@Component({
  selector: 'app-calender-view',
  standalone: true,
  imports: [],
  templateUrl: './calender-view.component.html',
  styleUrl: './calender-view.component.scss'
})
export class CalenderViewComponent {

}
