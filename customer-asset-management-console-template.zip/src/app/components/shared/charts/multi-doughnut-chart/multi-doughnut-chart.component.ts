import { Component } from '@angular/core';

@Component({
  selector: 'app-multi-doughnut-chart',
  standalone: true,
  imports: [],
  templateUrl: './multi-doughnut-chart.component.html',
  styleUrl: './multi-doughnut-chart.component.scss'
})
export class MultiDoughnutChartComponent {

}
