import { Component } from '@angular/core';

@Component({
  selector: 'app-recent-events',
  standalone: true,
  imports: [],
  templateUrl: './recent-events.component.html',
  styleUrl: './recent-events.component.scss'
})
export class RecentEventsComponent {

}
