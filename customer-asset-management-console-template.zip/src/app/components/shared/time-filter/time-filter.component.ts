import { Component } from '@angular/core';

@Component({
  selector: 'app-time-filter',
  standalone: true,
  imports: [],
  templateUrl: './time-filter.component.html',
  styleUrl: './time-filter.component.scss'
})
export class TimeFilterComponent {

}
