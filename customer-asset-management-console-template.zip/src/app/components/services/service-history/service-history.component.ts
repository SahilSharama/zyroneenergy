import { Component } from '@angular/core';

@Component({
  selector: 'app-service-history',
  standalone: true,
  imports: [],
  templateUrl: './service-history.component.html',
  styleUrl: './service-history.component.scss'
})
export class ServiceHistoryComponent {

}
