import { Component } from '@angular/core';

@Component({
  selector: 'app-asset-card',
  standalone: true,
  imports: [],
  templateUrl: './asset-card.component.html',
  styleUrl: './asset-card.component.scss'
})
export class AssetCardComponent {

}
