import { Component } from '@angular/core';

@Component({
  selector: 'app-invoice-list',
  standalone: true,
  imports: [],
  templateUrl: './invoice-list.component.html',
  styleUrl: './invoice-list.component.scss'
})
export class InvoiceListComponent {

}
