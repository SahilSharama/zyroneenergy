import { Component } from '@angular/core';

@Component({
  selector: 'app-specifications',
  standalone: true,
  imports: [],
  templateUrl: './specifications.component.html',
  styleUrl: './specifications.component.scss'
})
export class SpecificationsComponent {

}
