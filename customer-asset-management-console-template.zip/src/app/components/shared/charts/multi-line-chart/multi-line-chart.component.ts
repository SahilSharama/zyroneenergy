import { Component } from '@angular/core';

@Component({
  selector: 'app-multi-line-chart',
  standalone: true,
  imports: [],
  templateUrl: './multi-line-chart.component.html',
  styleUrl: './multi-line-chart.component.scss'
})
export class MultiLineChartComponent {

}
